var http = require('http');
var fs = require('fs');
var url = require('url');
var express = require('express');
var mysql = require('mysql');

var app = express();
app.set('view engine','ejs');
app.use( express.static( "public" ) );



/*var Users = {

  'David': {
    age: 52,
    occupation: 'Professor',
    hobby: 'Swimming'
  },

  'Robert': {
    age: 34,
    occupation: 'Engineer',
    hobby: 'Running'
  },

  'Jane': {
    age: 28,
    occupation: 'Nurse',
    hobby: 'Chess'
  }

};*/

//app.get('/user', function (req, res) {
//  var check = Users[req.query.name];
//  var info = (check) ? check : 'User does not exist...';
//  res.send(info);
//});

//app.get('/user', function (req, res) {
//  var check = Users[req.query.name];
//  if (check) {  
 //   res.render('./user.ejs', { name: req.query.name, info: check });
//  } else {
//	console.log('check not ok...');  
 //   res.send('User does not exist...!');
 // }
//});


 app.get('/Home.html', function(req, response){
	 fs.readFile('./views/Home.html', function(error, data) {  
                if (error) {  
                    response.writeHead(404);  
                    response.write(error);  
                    response.end();  
                } else {  
                    response.writeHead(200, {  
                        'Content-Type': 'text/html'  
                    });  
                    response.write(data);  
                    response.end();

					
					   }	  
            });  
 });
    
     
         
           
app.get('/Shop.html', function (req, response){
	 fs.readFile('./Shop.ejs', function(error, data) {  
                if (error) {  
                    response.writeHead(404);  
                    response.write(error);  
                    response.end();  
                } else {  
                     //response.writeHead(200, {  
                      //  'Content-Type': 'text/html'  
                    //}); 
					//response.write(data);  				
                    //response.end();  
					
//added here					
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'foo',
  password : 'bar',
  database : 'ae'
});

connection.connect();

connection.query('SELECT * from produse;', function (err, rows, fields) {
  if (err) return console.error(error.message);

	var r0 = rows[0];
	var r1 = rows[1];
	var r2 = rows[2];
	var r3 = rows[3];
	var r4 = rows[4];
  //console.log('The solution is: ', fields[0]); //ok
  //console.log(r0, r1, r2, r3, r4);
  response.render('./Shop.ejs', { info0:r0, info1:r1, info2:r2, info3:r3, info4:r4 }); 
  response.end();
});

connection.end();
						}  
}); 	
});           
          
            
             
 app.get('/Contact.html', function (req, response){        
            fs.readFile('./views/Contact.html', function(error, data) {  
                if (error) {  
                    response.writeHead(404);  
                    response.write(error);  
                    response.end();  
                } else {  
                    response.writeHead(200, {  
                        'Content-Type': 'text/html'  
                    });  
                    response.write(data);  
                    response.end();  
                }  
            });  
 });          
          
 app.get('/', function (req, response){        
		 fs.readFile('./views/Home.html', function(error, data) {  
                if (error) {  
                    response.writeHead(404);  
                    response.write(error);  
                    response.end();  
                } else {  
                    response.writeHead(200, {  
                        'Content-Type': 'text/html'  
                    });  
                    response.write(data);  
                    response.end();  
                }  
            });  
             
});
  
  
  
app.listen(3000, function(){console.log('Server listen at http://127.0.0.1:3000/')});
