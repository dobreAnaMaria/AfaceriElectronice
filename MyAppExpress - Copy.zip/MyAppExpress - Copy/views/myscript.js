
<link rel="stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
<script src ="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
<script src ="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.bundle.min.js"></script>

<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type="text/javascript">

//show cart
(function(){
var glyphiconShoppingCart = document.getElementById("glyphicon-shopping-cart");
var theCart = document.getElementById("cart");

glyphiconShoppingCart.addEventListener("click", function(){
theCart.classList.toggle("show-cart");
});
})();

//add items to cart
(function(){
const cartBtn = document.querySelectorAll(".addToCart");
cartBtn.forEach(function(btn){
btn.addEventListener("click", function(event){

let fullPathImage = event.target.parentElement.parentElement.parentElement.children[0].src;
let position = fullPathImage.indexOf("3000")+5;
let partPath = fullPathImage.slice(position);

//console.log(position);
//console.log(fullPathImage);
//console.log(partPath);

const item = {};
item.img = partPath;
//console.log(item);

let name = event.target.parentElement.parentElement.parentElement.children[2].textContent;
//console.log(name);
let ajustName = name.slice(25).trim();
item.name = ajustName;
//console.log(item);

let price = event.target.parentElement.parentElement.children[0].children[0].textContent;
let ajustPrice = price.slice(33).trim();
//console.log(ajustPrice);
item.price = ajustPrice;
console.log(item);


//creem sablonul pe care se vor afisa elementele de mai sus
let cart = document.createElement('div');
cart.classList.add("d-flex", "justify-content-between");

cart.innerHTML = `<img  class = "img-cart" src="${item.img}"/> <p class ="name">${item.name}</p> <p class ="price">${item.price}</p> <a href="#" class="glyphicon glyphicon-remove"></a>`;
for (var i =0;i<item.length;i++){
cart.appendChild(`<img src="${item[i].img}"/> <p class ="name">${item[i].name}</p> <p class ="price">${item[i].price}</p> <a href="#" class="glyphicon glyphicon-remove"></a>`);
}


//select the cart
//const mycart = document.getElementById("cart");
const total = document.getElementById("cart-total-container");
total.parentNode.insertBefore(cart, total);
showTotal();
});
});

function showTotal(){
const total = [];
const items = document.querySelectorAll(".price");

items.forEach(function(item){
total.push(parseFloat(item.textContent));
});
//console.log(total);

const totalMoney = total.reduce(function(total, item)
{
total+=item;
return total;
},0);
console.log(totalMoney);

document.getElementById("leitotal").textContent = totalMoney + " LEI";
}



})();

</script>